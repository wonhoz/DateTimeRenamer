using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.IO;

namespace exifEditor
{
    public partial class mainDlg : Form, IDisposable
    {
        private String m_currImageFile;
        private String m_currImageFileTemp;

        public mainDlg()
        {
            InitializeComponent();
            m_currImageFile = m_currImageFileTemp = "";

            // ������ �����Ǿ��� �ӽ� �̹����� �����մϴ�.
            try
            {
                DirectoryInfo di = new DirectoryInfo(Path.GetTempPath());

                FileInfo[] fi = di.GetFiles("__exifEditor__*.*");

                foreach (FileInfo f in fi)
                {
                    File.Delete(f.FullName);
                }
            }
            catch (Exception excep)
            {
                MessageBox.Show("�ӽ� ���� ���� ���� : " + excep.Message);
            }
        }
            
        private void m_btnChooseFile_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openDialog = new OpenFileDialog();

                openDialog.InitialDirectory = "g:\\temp\\New Folder";
                openDialog.Filter = "jpg files (*.jpg)|*.jpg|tif files (*.tif)|*.tif|bmp files (*.bmp)|*.bmp";
                openDialog.FilterIndex = 1;
                openDialog.Multiselect = true;
                openDialog.RestoreDirectory = false;
                openDialog.CheckFileExists = true;

                if (openDialog.ShowDialog() == DialogResult.OK)
                {
                    m_cmbImages.DataSource = openDialog.FileNames;
                }
            }
            catch (Exception excep)
            {
                MessageBox.Show("m_btnChooseFile_Click ���� : " + excep.Message);
            }
        }

        private void LoadCurrImage()
        {
            if (m_currImageFile == "") MessageBox.Show("LoadCurrImage ���� : ����� �̹����� �����ϴ�.");

            Cursor = Cursors.WaitCursor;
            try
            {
                m_currImageFileTemp = Path.GetTempPath() + "__exifEditor__" + Path.GetRandomFileName();

                File.Copy(m_currImageFile, m_currImageFileTemp);

                m_listViewProperties.Items.Clear();

                m_pBImage.SizeMode = PictureBoxSizeMode.Zoom;
                m_pBImage.Image = Image.FromFile(m_currImageFileTemp);

                // �̹����� �Ӽ��� �н��ϴ�.
                Image theImage = new Bitmap(m_currImageFileTemp);

                PropertyItem[] propItems = theImage.PropertyItems;

                // �迭�� �� PropertyItem�� ���� ID, ���� �� ���̸� ǥ���մϴ�.
                Encoding _Encoding = Encoding.UTF8;
                int count = 0;

                foreach (PropertyItem propItem in propItems)
                {
                    ListViewItem row = new ListViewItem("0x" + propItem.Id.ToString("x"));

                    switch (propItem.Id.ToString("x"))
                    {
                        case "10f":
                            row.SubItems.Add("Manufacturer");
                            m_textPropertyValue.Text = _Encoding.GetString(propItem.Value);
                            break;
                        case "110":
                            row.SubItems.Add("Model");
                            break;

                        case "132":
                            row.SubItems.Add("Created Date");
                            break;

                        case "9003":
                            row.SubItems.Add("DateTimeOriginal");
                            break;
                        case "9004":
                            row.SubItems.Add("Photo Date");

                            break;
                        case "9010":
                            row.SubItems.Add("OffsetTime");
                            break;

                        case "9011":
                           row.SubItems.Add("OffsetTimeOriginal");
                            break;

                        case "9012":
                            row.SubItems.Add("OffsetTimeDigitized");
                            break;

                        default:
                            row.SubItems.Add(count.ToString());
                            break;
                    }

                    row.SubItems.Add(_Encoding.GetString(propItem.Value));
                    m_listViewProperties.Items.Add(row);

                    count += 1;
                }
                m_listViewProperties.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                onResize(null, null);

                theImage.Dispose();
                ShowControls(true);
            }
            catch (Exception excep)
            {
                MessageBox.Show("Error : " + excep.Message);
            }
            Cursor = Cursors.Default;
        }

        private void ShowControls(bool p)
        {
            m_pBImage.Visible = p;
            m_listViewProperties.Visible = p;
            m_lblPropertyName.Visible = p;
            m_textPropertyValue.Visible = p;
            m_btnUpdate.Visible = p;
            m_btnUpdateAndJump.Visible = p;
        }

        private void onResize(object sender, EventArgs e)
        {
            Rectangle clientRect = this.ClientRectangle;
            int sideMargin = 16;
            int upperMargin = 43;
            int bottomMargin = 40;

            // �̹���
            m_pBImage.Left = sideMargin;
            m_pBImage.Top = upperMargin;
            m_pBImage.Width = (clientRect.Width - (3 * sideMargin)) / 2;
            m_pBImage.Height = clientRect.Height - bottomMargin - upperMargin;

            // �Ӽ�
            m_listViewProperties.Left = (clientRect.Width / 2) + (sideMargin / 2);
            m_listViewProperties.Top = upperMargin;
            m_listViewProperties.Width = (clientRect.Width - (3 * sideMargin)) / 2;
            m_listViewProperties.Height = clientRect.Height - bottomMargin - upperMargin;

            // �Ӽ� ��Ī
            m_lblPropertyName.Left = sideMargin;
            m_lblPropertyName.Top = clientRect.Height - 24;

            // �Ӽ� ��
            m_textPropertyValue.Left = m_lblPropertyName.Right + sideMargin;
            m_textPropertyValue.Top = clientRect.Height - 28;

            // ������Ʈ ��ư
            m_btnUpdate.Left = m_textPropertyValue.Right + sideMargin;
            m_btnUpdate.Top = clientRect.Height - 30;

            // ������Ʈ �� �ѱ�� ��ư
            m_btnUpdateAndJump.Left = m_btnUpdate.Right + sideMargin;
            m_btnUpdateAndJump.Top = clientRect.Height - 30;
        }

        private void m_btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Encoding _Encoding              = Encoding.UTF8;
                Image theImage                  = new Bitmap(m_currImageFileTemp);

                PropertyItem propItem271 = theImage.GetPropertyItem(271);
                PropertyItem propItem272 = theImage.GetPropertyItem(272);

                propItem271.Value = _Encoding.GetBytes(m_textPropertyValue.Text + '\0');
                propItem272.Value = _Encoding.GetBytes(m_textPropertyValue.Text + '\0');

                propItem271.Id = 271;
                propItem272.Id = 272;

                theImage.SetPropertyItem(propItem271);
                theImage.SetPropertyItem(propItem272);

                theImage.Save(m_currImageFile);

                // ����� �̹����� �ٽ� �ε��մϴ�.
                ShowControls(false);
                LoadCurrImage();
            }
            catch (Exception excp)
            {
                MessageBox.Show("m_btnUpdate_Click ���� : " + excp.Message);
            }
        }

        private void m_btnUpdateAndJump_Click(object sender, EventArgs e)
        {
            try
            {
                Encoding _Encoding = Encoding.UTF8;
                Image theImage = new Bitmap(m_currImageFileTemp);
                PropertyItem propItem36867 = theImage.GetPropertyItem(36867);
                PropertyItem propItem36868 = theImage.GetPropertyItem(36868);

                propItem36867.Value = _Encoding.GetBytes(m_textPropertyValue.Text + '\0');
                propItem36868.Value = _Encoding.GetBytes(m_textPropertyValue.Text + '\0');

                theImage.SetPropertyItem(propItem36867);
                theImage.SetPropertyItem(propItem36868);

                theImage.Save(m_currImageFile);

                // ����� �̹����� �ٽ� �ε��մϴ�.
                ShowControls(false);

                // �̹����� ������Ʈ�մϴ�.
                int currIndex = m_cmbImages.SelectedIndex + 1;

                if (currIndex >= m_cmbImages.Items.Count)
                {
                    Console.Beep();
                    onChangeImageCombo(null, null);
                }
                else
                    m_cmbImages.SelectedIndex = currIndex;
            }
            catch (Exception excp)
            {
                MessageBox.Show("Error m_btnUpdate_Click ���� : " + excp.Message);
            }
        }


        private void onChangeImageCombo(object sender, EventArgs e)
        {
            m_currImageFile = m_cmbImages.SelectedItem.ToString();
            m_lblCounter.Text = Convert.ToString(m_cmbImages.SelectedIndex + 1) + " / " + m_cmbImages.Items.Count;
            m_cmbImages.Focus();
            LoadCurrImage();
        }

        private void mainDlg_Load(object sender, EventArgs e)
        {

        }
    }
}